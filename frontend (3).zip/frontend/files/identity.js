window.IDENTITY_ITEMS = [
    {
        name: 'Readme.txt',
        type: 'txt',
        content: `FAKE PASSPORTS WARNING
═══════════════════════
Summary
- Explains biometric security features in modern passports.
- Outlines legal penalties for forgery and identity fraud.

Takeaway
Always use legitimate government-issued identification.`
    },
    {
        name: 'Index.txt',
        type: 'txt',
        content: `CITIZENSHIP DOCUMENTATION
══════════════════════════
    The Hidden Wiki:
        https://thehiddenwiki.org/
`
    },
];
