window.INFORMATION_ITEMS = [
    {
        name: 'README.txt',
        type: 'txt',
        content: `INFORMATION ARCHIVE
═══════════════════

Reference library for intel reports, leaked datasets, and
verification methods. See Index.txt for sections.`
    },
    {
        name: 'Index.txt',
        type: 'txt',
        content: `INFORMATION INDEX
═════════════════
Darknet Bible:
    http://biblemeowimkh3utujmhm6oh2oeb3ubjw2lpgeq3lahrfr2l6ev6zgyd.onion/

Opspec:
    http://jqibjqqagao3peozxfs53tr6aecoyvctumfsc2xqniu4xgcrksal2iqd.onion/

Vormweb:
    http://volkancfgpi4c7ghph6id2t7vcntenuly66qjt6oedwtjmyj4tkk5oqd.onion/

DuckDuckGo:
    https://duckduckgogg42xjoc72x3sjasowoarfbgcmvfimaftt6twagswzczad.onion/
`}
];
