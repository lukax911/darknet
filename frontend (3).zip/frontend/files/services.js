window.SERVICES_ITEMS = [
    {
        name: 'README.txt',
        type: 'txt',
        content: `SERVICES HUB
═════════════

Managed offerings, support crews, and contact workflows. Review
Index.txt to see available service categories.`
    },
    {
        name: 'Index.txt',
        type: 'txt',
        content: `SERVICES INDEX
══════════════
Onion Share:
    http://lldan5gahapx5k7iafb3s4ikijc4ni7gx5iywdflkba5y2ezyg6sjgyd.onion/

Feather Wallet:
    http://featherdvtpi7ckdbkb2yxjfwx3oyvr3xjz3oo4rszylfzjdg6pbm3id.onion/

Archive.is:
    http://archiveiya74codqgiixo33q62qlrqtkgmcitqx5u2oeqnmn5bpcbiyd.onion/

Njal.la:
    http://njallalafimoej5i4eg7vlnqjvmb6zhdh27qxcatdn647jtwwwui3nad.onion/

Mullvad:
    http://o54hon2e2vj6c7m3aqqu6uyece65by3vgoxxhlqlsvkmacw6a7m7kiad.onion/

Cryptostorm:
    http://stormwayszuh4juycoy4kwoww5gvcu2c4tdtpkup667pdwe4qenzwayd.onion/

Simply Translate:
    http://xxtbwyb5z5bdvy2f6l2yquu5qilgkjeewno4qfknvb3lkg3nmoklitid.onion/

Monero:
    http://monerotoruzizulg5ttgat2emf4d6fbmiea25detrmmy7erypseyteyd.onion/

Block Chair:
    http://blkchairbknpn73cfjhevhla7rkp4ed5gg2knctvv7it4lioy22defid.onion/

Monero.fail:
    http://livk2fpdv4xjnjrbxfz2tw3ptogqacn2dwfzxbxr3srinryxrcewemid.onion/
`
    }
];
