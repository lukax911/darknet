window.FORUMS_ITEMS = [
    {
        name: 'README.txt',
        type: 'txt',
        content: `FORUMS DIRECTORY
════════════════

Community hubs and discussion boards curated by topic. Use
Index.txt for quick navigation.`
    },
    {
        name: 'Index.txt',
        type: 'txt',
        content: `FORUMS INDEX
═════════════
Dread:
    https://dreadytofatroptsdj6io7l3xptbet6onoyno2yv7jicoxknyazubrad.onion/

Pitch:
    http://pitchprash4aqilfr7sbmuwve3pnkpylqwxjbj2q5o4szcfeea6d27yd.onion/

NZ forum:
    http://nzdnmfcf2z5pd3vwfyfy3jhwoubv6qnumdglspqhurqnuvr52khatdad.onion/

Germania:
    http://germania7zs27fu3gi76wlr5rd64cc2yjexyzvrbm4jufk7pibrpizad.onion/

End Chan:
    http://endchancxfbnrfgauuxlztwlckytq7rgeo5v6pc2zd4nyqo3khfam4ad.onion/

Dark Forest:
    http://dkforestseeaaq2dqz2uflmlsybvnq2irzn4ygyvu53oazyorednviid.onion/
`}
];
