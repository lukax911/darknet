window.MARKETS_ITEMS = [
    {
        name: 'README.txt',
        type: 'txt',
        content: `MARKETS & EXCHANGES HUB
═════════════════════════

Central place for market intel, escrow basics, and exchange
watchlists. Consult Index.txt for the full breakdown.`
    },
    {
        name: 'Index.txt',
        type: 'txt',
        content: `MARKETS & EXCHANGES INDEX
════════════════════════

    The Hidden Wiki:
        https://thehiddenwiki.org/

    Tor.taxi:
        https://tor.taxi/
`
    }
];
