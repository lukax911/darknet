window.EMAIL_JABBER_ITEMS = [
    {
        name: 'README.txt',
        type: 'txt',
        content: `EMAIL & JABBER DIRECTORY
═══════════════════════════

This folder aggregates secure messaging resources. Start with
Index.txt to browse providers, client guides, and OPSEC tips.`
    },
    {
        name: 'Index.txt',
        type: 'txt',
        content: `EMAIL & JABBER INDEX
══════════════════════
Proton Mail:
   http://protonmailrmez3lotccipshtkleegetolb73fuirgj7r4o4vfu7ozyd.onion/

Piss Mail:
    http://pissmaiamldg5ciulncthgzudvh5d55dismyqf6qdkx372n2b5osefid.onion/

XMPP.is:
    http://6voaf7iamjpufgwoulypzwwecsm2nu7j5jpgadav2rfqixmpl4d65kid.onion/
    
Morke.org:
    http://6n5nbusxgyw46juqo3nt5v4zuivdbc7mzm74wlhg7arggetaui4yp4id.onion/

Underworld:
    http://fozdean5ayswi6jtseg2fgyysqt3dskoosmoc6gnqia4dxwxiuvg3oad.onion/

Rise Up:
    http://vww6ybal4bd7szmgncyruucpgfkqahzddi37ktceo3ah7ngmcopnpyyd.onion/

AltAddress.org:
    http://tp7mtouwvggdlm73vimqkuq7727a4ebrv4vf4cnk6lfg4fatxa6p2ryd.onion/

Cock.li:
    http://rurcblzhmdk22kttfkel2zduhyu3r6to7knyc7wiorzrx5gw4c3lftad.onion/

Danwin1210.de:
    http://danielas3rtn54uwmofdo3x2bsdifr47huasnmbgqzfrec5ubupvtpid.onion/

    `}
];
