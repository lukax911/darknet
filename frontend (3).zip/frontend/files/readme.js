window.README_TITLE = 'README.txt';

window.README_CONTENT = `HELLO OPERATIVE
════════════════════════════════

We Strongly Suggest that you use Tor or Brave Browser for this project

In brave go to the three dots found in the top right and click new private window with tor please

If you do not have any of these installed we will provide you with the links

TOR:

    https://www.torproject.org/download/

BRAVE:
    https://brave.com/download/

.onion urls will not work in normal browser as they cant find the onion network


`;
